/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionadquisiciones;

/**
 *
 * @author oswgu
 */
public class GestionAdquisiciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginAndRegister.Base objetoLogIn = new LoginAndRegister.Base();
        objetoLogIn.setVisible(true);
    }
    
}
