/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class conexionSQLServer {
    
    String hostname = null;
    String port     = null;
    String database = null;
    String username = null;
    String password = null;
    String jndi     = null;
    
    static Properties props = new Properties();
    
    public conexionSQLServer(){
    InputStream in = null;
        try {
            in = Files.newInputStream(FileSystems.getDefault().getPath("C:\\Users\\oswgu\\OneDrive\\Documents\\NetBeansProjects\\GestionAdquisiciones\\src\\conexion\\db_properties.properties"));
            props.load(in);
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try {
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        loadProperties();
    }
    public void loadProperties(){
        hostname    = props.getProperty("hostname");
        port        = props.getProperty("port");
        database    = props.getProperty("database");
        username    = props.getProperty("username");
        password    = props.getProperty("password");
        jndi        = props.getProperty("jndi");
    }
    
    public Connection getConnection() throws SQLException{
        Connection conn = null;
        String jdbcUrl = "jdbc:sqlserver://" +this.hostname+ ":" +this.port+ ";databaseName=" +this.database+";encrypt=true;trustServerCertificate=true;";
        
        conn = (Connection) DriverManager.getConnection(jdbcUrl,username,password);
        System.out.println("CONEXION ESTABLE");
        
        return conn;
    }
    
    public Connection getDSConnection(){
    Connection conn = null;
        try {
            Context ctx = new InitialContext();
            DataSource ds = (DataSource)ctx.lookup(this.jndi);
            conn = ds.getConnection();
        } catch (NamingException | SQLException e) {
            e.printStackTrace();
        }
    return conn;
    }
}
