/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LoginAndRegister;

import java.sql.*;
import java.util.HashSet;
import java.util.Set;

/**
 * DAO para gestionar permisos de usuarios
 * Maneja roles y botones/pantallas permitidas
 */
public class PermisosDAO {
    private Connection conexion;
    
    public PermisosDAO(Connection conexion) {
        this.conexion = conexion;
    }
    
    /**
     * Obtiene todos los roles asignados a un usuario
     * @param usuarioID ID del usuario
     * @return Set con los IDs de roles asignados
     * @throws SQLException si hay error en la consulta
     */
    public Set<Integer> obtenerRolesUsuario(int usuarioID) throws SQLException {
        Set<Integer> roles = new HashSet<>();
        String sql = "SELECT RolID FROM UsuarioRoles WHERE UsuarioID = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, usuarioID);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                roles.add(rs.getInt("RolID"));
            }
            
            rs.close();
        }
        
        System.out.println("Roles obtenidos para usuario " + usuarioID + ": " + roles);
        return roles;
    }
    
    /**
     * Obtiene todos los botones/pantallas permitidas para un usuario basado en sus roles
     * @param usuarioID ID del usuario
     * @return Set con los códigos de botones permitidos
     * @throws SQLException si hay error en la consulta
     */
    public Set<String> obtenerPantallasPermitidas(int usuarioID) throws SQLException {
        Set<String> botones = new HashSet<>();
        
        String sql = "SELECT DISTINCT p.CodigoPantalla " +
                     "FROM Pantallas p " +
                     "INNER JOIN RolPantallas rp ON p.PantallaID = rp.PantallaID " +
                     "INNER JOIN UsuarioRoles ur ON rp.RolID = ur.RolID " +
                     "WHERE ur.UsuarioID = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, usuarioID);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                botones.add(rs.getString("CodigoPantalla"));
            }
            
            rs.close();
        }
        
        System.out.println("Botones permitidos para usuario " + usuarioID + ": " + botones);
        return botones;
    }
    
    /**
     * Alias para mantener compatibilidad - obtiene botones permitidos
     */
    public Set<String> obtenerBotonesPermitidos(int usuarioID) throws SQLException {
        return obtenerPantallasPermitidas(usuarioID);
    }
    
    /**
     * Verifica si un usuario tiene acceso a un botón/pantalla específica
     * @param usuarioID ID del usuario
     * @param codigoBoton Código del botón
     * @return true si tiene acceso, false en caso contrario
     * @throws SQLException si hay error en la consulta
     */
    public boolean verificarAcceso(int usuarioID, String codigoBoton) throws SQLException {
        String sql = "SELECT COUNT(*) as tiene_acceso " +
                     "FROM Pantallas p " +
                     "INNER JOIN RolPantallas rp ON p.PantallaID = rp.PantallaID " +
                     "INNER JOIN UsuarioRoles ur ON rp.RolID = ur.RolID " +
                     "WHERE ur.UsuarioID = ? AND p.CodigoPantalla = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, usuarioID);
            ps.setString(2, codigoBoton);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                boolean tieneAcceso = rs.getInt("tiene_acceso") > 0;
                rs.close();
                return tieneAcceso;
            }
            
            rs.close();
        }
        
        return false;
    }
    
    /**
     * Obtiene el nombre descriptivo de un rol
     * @param rolID ID del rol
     * @return Nombre del rol
     * @throws SQLException si hay error en la consulta
     */
    public String obtenerNombreRol(int rolID) throws SQLException {
        String sql = "SELECT NombreRol FROM Roles WHERE RolID = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, rolID);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                String nombre = rs.getString("NombreRol");
                rs.close();
                return nombre;
            }
            
            rs.close();
        }
        
        return "Rol Desconocido";
    }
    
    /**
     * Obtiene todos los roles disponibles en el sistema
     * @return Set con los IDs de todos los roles
     * @throws SQLException si hay error en la consulta
     */
    public Set<Integer> obtenerTodosLosRoles() throws SQLException {
        Set<Integer> roles = new HashSet<>();
        String sql = "SELECT RolID FROM Roles";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                roles.add(rs.getInt("RolID"));
            }
            
            rs.close();
        }
        
        return roles;
    }
    
    /**
     * Obtiene todas las pantallas/botones disponibles
     * @return Set con todos los códigos de pantallas
     * @throws SQLException si hay error en la consulta
     */
    public Set<String> obtenerTodasLasPantallas() throws SQLException {
        Set<String> pantallas = new HashSet<>();
        String sql = "SELECT CodigoPantalla FROM Pantallas";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                pantallas.add(rs.getString("CodigoPantalla"));
            }
            
            rs.close();
        }
        
        return pantallas;
    }
}
