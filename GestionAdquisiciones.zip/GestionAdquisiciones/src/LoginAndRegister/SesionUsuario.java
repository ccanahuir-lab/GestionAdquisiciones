/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LoginAndRegister;

import java.util.HashSet;
import java.util.Set;

/**
 * Clase Singleton para mantener la información de la sesión del usuario
 * Almacena: ID, nombre, roles y botones/pantallas permitidas
 */
public class SesionUsuario {
    private static SesionUsuario instancia;
    
    private int usuarioID;
    private String nombreUsuario;
    private Set<Integer> rolesIDs;
    private Set<String> botonesPermitidos; // Códigos de botones/pantallas permitidas
    
    private SesionUsuario() {
        rolesIDs = new HashSet<>();
        botonesPermitidos = new HashSet<>();
    }
    
    public static SesionUsuario getInstancia() {
        if (instancia == null) {
            instancia = new SesionUsuario();
        }
        return instancia;
    }
    
    /**
     * Inicia sesión para un usuario con sus roles y permisos
     * @param usuarioID ID del usuario
     * @param nombreUsuario Nombre del usuario
     * @param roles Set de IDs de roles asignados
     * @param botones Set de códigos de botones/pantallas permitidas
     */
    public void iniciarSesion(int usuarioID, String nombreUsuario, 
                              Set<Integer> roles, Set<String> botones) {
        this.usuarioID = usuarioID;
        this.nombreUsuario = nombreUsuario;
        this.rolesIDs = new HashSet<>(roles); // Copia defensiva
        this.botonesPermitidos = new HashSet<>(botones); // Copia defensiva
    }
    
    /**
     * Cierra la sesión actual y limpia todos los datos
     */
    public void cerrarSesion() {
        usuarioID = 0;
        nombreUsuario = null;
        rolesIDs.clear();
        botonesPermitidos.clear();
        System.out.println("🔒 Sesión cerrada correctamente");
    }
    
    /**
     * Verifica si el usuario tiene acceso a un botón/pantalla específica
     * @param codigoBoton Código del botón (ej: "USUARIOS", "CREAR_PEDIDO")
     * @return true si tiene acceso, false en caso contrario
     */
    public boolean tieneAccesoBoton(String codigoBoton) {
        return botonesPermitidos.contains(codigoBoton);
    }
    
    /**
     * Alias de tieneAccesoBoton para mantener compatibilidad
     */
    public boolean tieneAcceso(String codigoBoton) {
        return tieneAccesoBoton(codigoBoton);
    }
    
    /**
     * Verifica si el usuario tiene un rol específico
     * @param rolID ID del rol a verificar
     * @return true si tiene el rol, false en caso contrario
     */
    public boolean tieneRol(int rolID) {
        return rolesIDs.contains(rolID);
    }
    
    /**
     * Verifica si el usuario es administrador del sistema
     * @return true si es administrador (RolID = 1)
     */
    public boolean esAdministrador() {
        return rolesIDs.contains(1); // ID del rol Administrador
    }
    
    /**
     * Verifica si el usuario es gestor de compras
     * @return true si es gestor de compras (RolID = 2)
     */
    public boolean esGestorCompras() {
        return rolesIDs.contains(2);
    }
    
    /**
     * Verifica si el usuario es administrador de proveedor
     * @return true si es admin proveedor (RolID = 3)
     */
    public boolean esAdminProveedor() {
        return rolesIDs.contains(3);
    }
    
    /**
     * Verifica si el usuario es auditor
     * @return true si es auditor (RolID = 4)
     */
    public boolean esAuditor() {
        return rolesIDs.contains(4);
    }
    
    /**
     * Verifica si hay una sesión activa
     * @return true si hay usuario logueado
     */
    public boolean haySesionActiva() {
        return usuarioID > 0 && nombreUsuario != null && !nombreUsuario.isEmpty();
    }
    
    // ===== GETTERS =====
    
    public int getUsuarioID() { 
        return usuarioID; 
    }
    
    public String getNombreUsuario() { 
        return nombreUsuario; 
    }
    
    public Set<Integer> getRolesIDs() { 
        return new HashSet<>(rolesIDs); // Devolver copia para evitar modificaciones
    }
    
    public Set<String> getBotonesPermitidos() { 
        return new HashSet<>(botonesPermitidos); // Devolver copia
    }
    
    /**
     * Alias para mantener compatibilidad con código antiguo
     */
    public Set<String> getPantallasPermitidas() { 
        return getBotonesPermitidos();
    }
    
    /**
     * Obtiene la cantidad de botones permitidos
     */
    public int getCantidadBotonesPermitidos() {
        return botonesPermitidos.size();
    }
    
    /**
     * Obtiene información completa de la sesión como String
     */
    @Override
    public String toString() {
        return "SesionUsuario{" +
                "usuarioID=" + usuarioID +
                ", nombreUsuario='" + nombreUsuario + '\'' +
                ", roles=" + rolesIDs +
                ", botonesPermitidos=" + botonesPermitidos.size() +
                '}';
    }
}
