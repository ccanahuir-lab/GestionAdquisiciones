/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Windows;

import conexion.conexionSQLServer;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.math.BigDecimal;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
public class PanelReportes extends javax.swing.JPanel {

    /**
     * Creates new form PanelReportes
     */
    public PanelReportes() {
        initComponents();
        
        inicializarModelos();
        cargarDatosIniciales();
    }
    
    private void inicializarModelos() {
    // Modelo Historial
    modeloHistorial = (DefaultTableModel) tblHistorial.getModel();
    modeloHistorial.setColumnIdentifiers(new String[]{
        "Artículo", "Código", "Proveedor", "Contacto", "Precio Unit.", 
        "Cantidad", "Monto Total", "Fecha Resolución", "Presentación"
    });
    
    // Modelo Ranking
    modeloRanking = (DefaultTableModel) tblRanking.getModel();
    modeloRanking.setColumnIdentifiers(new String[]{
        "Ranking", "Proveedor", "Contacto", "Teléfono", "Email", 
        "Total Adjudicaciones", "Monto Total", "Precio Promedio"
    });
    
    // Modelo Ofertas
    modeloOfertas = (DefaultTableModel) tblOfertas.getModel();
    modeloOfertas.setColumnIdentifiers(new String[]{
        "Artículo", "Presentación", "Cant. Solicitada", "Proveedor", 
        "Precio Ofertado", "Monto Total", "Condiciones Pago", 
        "Fecha Entrega", "Estado"
    });
    
    // Modelo Pendientes
    modeloPendientes = (DefaultTableModel) tblPendientes.getModel();
    modeloPendientes.setColumnIdentifiers(new String[]{
        "ID Pedido", "Solicitante", "Cargo", "Departamento", "Sucursal", 
        "Fecha Pedido", "Fecha Estimada", "Estado", "Días Pendiente"
    });
    
    // Modelo Activas
    modeloActivas = (DefaultTableModel) tblActivas.getModel();
    modeloActivas.setColumnIdentifiers(new String[]{
        "ID Orden", "Fecha Emisión", "Fecha Límite", "Días Restantes", 
        "Responsable", "Prioridad", "Estado", "Items", "Proveedores"
    });
    
    // Modelo Gastos
    modeloGastos = (DefaultTableModel) tblGastos.getModel();
    modeloGastos.setColumnIdentifiers(new String[]{
        "Departamento", "Sucursal", "Total Órdenes", "Total Adjudicaciones", 
        "Monto Total", "Precio Promedio", "Primera Compra", "Última Compra"
    });
    
    // Modelo Eficiencia
    modeloEficiencia = (DefaultTableModel) tblEficiencia.getModel();
    modeloEficiencia.setColumnIdentifiers(new String[]{
        "Prioridad", "Total Órdenes", "Días Promedio", "Días Mínimo", "Días Máximo"
    });
    
    // Modelo Variación
    modeloVariacion = (DefaultTableModel) tblVariacion.getModel();
    modeloVariacion.setColumnIdentifiers(new String[]{
        "Artículo", "Presentación", "Proveedor", "Fecha Oferta", 
        "Precio Ofertado", "Precio Anterior", "Variación $", 
        "Variación %", "Resultado", "Condiciones"
    });
}
    
    private void cargarDatosIniciales() {
    cargarArticulos();
    cargarOrdenesCompra();
    cargarSucursales();
    cargarArticulosVar();
    configurarSpinner();
}
    
    private void cargarArticulos() {
    Connection tempConn = null;
    PreparedStatement tempPs = null;
    ResultSet tempRs = null;
    
    try {
        tempConn = cn.getConnection();
        qry = "SELECT Nombre FROM ARTICULOS ORDER BY Nombre";
        tempPs = tempConn.prepareStatement(qry);
        tempRs = tempPs.executeQuery();
        
        cbArticulo.removeAllItems();
        while (tempRs.next()) {
            cbArticulo.addItem(tempRs.getString("Nombre"));
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar artículos: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (tempRs != null) tempRs.close();
            if (tempPs != null) tempPs.close();
            if (tempConn != null) tempConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    
    private void cargarOrdenesCompra() {
    Connection tempConn = null;
    PreparedStatement tempPs = null;
    ResultSet tempRs = null;
    
    try {
        tempConn = cn.getConnection();
        qry = "SELECT ID, Fecha_Emision FROM ORDENES_DE_COMPRA ORDER BY Fecha_Emision DESC";
        tempPs = tempConn.prepareStatement(qry);
        tempRs = tempPs.executeQuery();
        
        cbOrdenCompra.removeAllItems();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        while (tempRs.next()) {
            String item = tempRs.getInt("ID") + " - " + sdf.format(tempRs.getTimestamp("Fecha_Emision"));
            cbOrdenCompra.addItem(item);
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar órdenes: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (tempRs != null) tempRs.close();
            if (tempPs != null) tempPs.close();
            if (tempConn != null) tempConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    
    private void cargarSucursales() {
    Connection tempConn = null;
    PreparedStatement tempPs = null;
    ResultSet tempRs = null;
    
    try {
        tempConn = cn.getConnection();
        qry = "SELECT Nombre FROM SUCURSALES WHERE Activo = 1 ORDER BY Nombre";
        tempPs = tempConn.prepareStatement(qry);
        tempRs = tempPs.executeQuery();
        
        cbSucursal.removeAllItems();
        while (tempRs.next()) {
            cbSucursal.addItem(tempRs.getString("Nombre"));
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar sucursales: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (tempRs != null) tempRs.close();
            if (tempPs != null) tempPs.close();
            if (tempConn != null) tempConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    
    private void cargarArticulosVar() {
    Connection tempConn = null;
    PreparedStatement tempPs = null;
    ResultSet tempRs = null;
    
    try {
        tempConn = cn.getConnection();
        qry = "SELECT Nombre FROM ARTICULOS ORDER BY Nombre";
        tempPs = tempConn.prepareStatement(qry);
        tempRs = tempPs.executeQuery();
        
        cbArticuloVar.removeAllItems();
        while (tempRs.next()) {
            cbArticuloVar.addItem(tempRs.getString("Nombre"));
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al cargar artículos: " + e.getMessage());
        e.printStackTrace();
    } finally {
        try {
            if (tempRs != null) tempRs.close();
            if (tempPs != null) tempPs.close();
            if (tempConn != null) tempConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    
    private void configurarSpinner() {
    SpinnerNumberModel spinnerModel = new SpinnerNumberModel(2024, 2000, 2100, 1);
    spAnio.setModel(spinnerModel);
}
    
    private void cerrarConexiones() {
    try {
        if (rs != null) rs.close();
        if (ps != null) ps.close();
        if (conn != null) conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    private void cargarProveedoresPorArticulo() {
    String articuloSel = (String) cbArticuloVar.getSelectedItem();
    if (articuloSel == null) return;
    
    Connection tempConn = null;
    PreparedStatement tempPs = null;
    ResultSet tempRs = null;
    
    cbProveedorVar.removeAllItems();
    
    try {
        tempConn = cn.getConnection();
        
        qry = "SELECT DISTINCT PROV.ID, PROV.Empresa " +
              "FROM PROVEEDORES PROV " +
              "INNER JOIN OFERTA_PROVEEDOR OP ON PROV.ID = OP.Fk_ProveedorID " +
              "INNER JOIN DETALLE_ORDEN_COMPRA DOC ON OP.Fk_DetalleOrdenID = DOC.ID " +
              "INNER JOIN PRESENTACIONES PRES ON DOC.Fk_PresentacionID = PRES.ID " +
              "INNER JOIN ARTICULOS A ON PRES.Fk_ArticuloID = A.ID " +
              "WHERE A.Nombre = ? " +
              "ORDER BY PROV.Empresa";
        
        tempPs = tempConn.prepareStatement(qry);
        tempPs.setString(1, articuloSel);
        tempRs = tempPs.executeQuery();
        
        while (tempRs.next()) {
            cbProveedorVar.addItem(tempRs.getInt("ID") + " - " + tempRs.getString("Empresa"));
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (tempRs != null) tempRs.close();
            if (tempPs != null) tempPs.close();
            if (tempConn != null) tempConn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cbArticulo = new javax.swing.JComboBox<>();
        btnBuscarHistorial = new javax.swing.JButton();
        btnExportarHistorial = new javax.swing.JButton();
        scrollPane1 = new java.awt.ScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHistorial = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        dtFechaInicio = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        dtFechaFin = new com.toedter.calendar.JDateChooser();
        btnBuscarRanking = new javax.swing.JButton();
        scrollPane2 = new java.awt.ScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblRanking = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cbOrdenCompra = new javax.swing.JComboBox<>();
        btnBuscarOfertas = new javax.swing.JButton();
        lblResumenOfertas = new javax.swing.JLabel();
        scrollPane3 = new java.awt.ScrollPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblOfertas = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        btnCargarPendientes = new javax.swing.JButton();
        lblTotalPendientes = new javax.swing.JLabel();
        scrollPane4 = new java.awt.ScrollPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblPendientes = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        btnCargarActivas = new javax.swing.JButton();
        lblTotalActivas = new javax.swing.JLabel();
        scrollPane5 = new java.awt.ScrollPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblActivas = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        cbSucursal = new javax.swing.JComboBox<>();
        lblAnio = new javax.swing.JLabel();
        spAnio = new javax.swing.JSpinner();
        btnBuscarGastos = new javax.swing.JButton();
        lblTotalGasto = new javax.swing.JLabel();
        scrollPane6 = new java.awt.ScrollPane();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblGastos = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        btnCalcularEficiencia = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        lblPromedio = new javax.swing.JLabel();
        lblMinimo = new javax.swing.JLabel();
        lblMaximo = new javax.swing.JLabel();
        lblDesviacion = new javax.swing.JLabel();
        scrollPane7 = new java.awt.ScrollPane();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblEficiencia = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        lblArticuloVar = new javax.swing.JLabel();
        cbArticuloVar = new javax.swing.JComboBox<>();
        lblProveedor = new javax.swing.JLabel();
        cbProveedorVar = new javax.swing.JComboBox<>();
        btnBuscarVariacion = new javax.swing.JButton();
        scrollPane8 = new java.awt.ScrollPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblVariacion = new javax.swing.JTable();

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setText("Articulo:");
        jPanel9.add(jLabel1);

        cbArticulo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel9.add(cbArticulo);

        btnBuscarHistorial.setText("Buscar");
        btnBuscarHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarHistorialActionPerformed(evt);
            }
        });
        jPanel9.add(btnBuscarHistorial);

        btnExportarHistorial.setText("Exportar");
        jPanel9.add(btnExportarHistorial);

        tblHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblHistorial);

        scrollPane1.add(jScrollPane1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(scrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(176, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Historial Compras", jPanel1);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel2.setText("Fecha Inicio:");
        jPanel10.add(jLabel2);
        jPanel10.add(dtFechaInicio);

        jLabel3.setText("Fecha Fin:");
        jPanel10.add(jLabel3);
        jPanel10.add(dtFechaFin);

        btnBuscarRanking.setText("Buscar Ranking");
        btnBuscarRanking.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarRankingActionPerformed(evt);
            }
        });
        jPanel10.add(btnBuscarRanking);

        tblRanking.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblRanking);

        scrollPane2.add(jScrollPane2);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(273, 273, 273)
                .addComponent(scrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(167, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Ranking Proveedores", jPanel2);

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel4.setText("Orden de compra:");
        jPanel11.add(jLabel4);

        cbOrdenCompra.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel11.add(cbOrdenCompra);

        btnBuscarOfertas.setText("Buscar Ofertas");
        btnBuscarOfertas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarOfertasActionPerformed(evt);
            }
        });
        jPanel11.add(btnBuscarOfertas);

        lblResumenOfertas.setText("Resumen:");
        jPanel11.add(lblResumenOfertas);

        tblOfertas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblOfertas);

        scrollPane3.add(jScrollPane3);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(267, 267, 267)
                .addComponent(scrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Analisis Ofertas", jPanel3);

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        btnCargarPendientes.setText("Cargar Pendientes");
        btnCargarPendientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarPendientesActionPerformed(evt);
            }
        });
        jPanel12.add(btnCargarPendientes);

        lblTotalPendientes.setText("Total: 0");
        jPanel12.add(lblTotalPendientes);

        tblPendientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(tblPendientes);

        scrollPane4.add(jScrollPane4);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(252, 252, 252)
                .addComponent(scrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Pedidos Pendientes", jPanel4);

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        btnCargarActivas.setText("Cargar Activas");
        btnCargarActivas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarActivasActionPerformed(evt);
            }
        });
        jPanel13.add(btnCargarActivas);

        lblTotalActivas.setText("Total: 0");
        jPanel13.add(lblTotalActivas);

        tblActivas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane5.setViewportView(tblActivas);

        scrollPane5.add(jScrollPane5);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(220, 220, 220)
                .addComponent(scrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Ordenes Activas", jPanel5);

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel5.setText("Sucursal:");
        jPanel14.add(jLabel5);

        cbSucursal.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel14.add(cbSucursal);

        lblAnio.setText("Año:");
        jPanel14.add(lblAnio);
        jPanel14.add(spAnio);

        btnBuscarGastos.setText("Buscar Gastos");
        btnBuscarGastos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarGastosActionPerformed(evt);
            }
        });
        jPanel14.add(btnBuscarGastos);

        lblTotalGasto.setText("Total: Q 0.00");
        jPanel14.add(lblTotalGasto);

        tblGastos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tblGastos);

        scrollPane6.add(jScrollPane6);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(231, 231, 231)
                .addComponent(scrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 551, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Gasto Departamental", jPanel6);

        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel15.setLayout(new java.awt.BorderLayout());

        btnCalcularEficiencia.setText("Calcular Eficiencia");
        btnCalcularEficiencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularEficienciaActionPerformed(evt);
            }
        });
        jPanel15.add(btnCalcularEficiencia, java.awt.BorderLayout.LINE_START);

        jPanel17.setLayout(new java.awt.GridLayout(1, 0));
        jPanel15.add(jPanel17, java.awt.BorderLayout.PAGE_END);

        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        lblPromedio.setText("Dias promedio: 0");

        lblMinimo.setText("Dias minimo: 0");

        lblMaximo.setText("Dias maximo: 0");

        lblDesviacion.setText("Desviacion: 0");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPromedio)
                    .addComponent(lblMinimo)
                    .addComponent(lblMaximo)
                    .addComponent(lblDesviacion))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPromedio)
                .addGap(18, 18, 18)
                .addComponent(lblMinimo)
                .addGap(18, 18, 18)
                .addComponent(lblMaximo)
                .addGap(18, 18, 18)
                .addComponent(lblDesviacion)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblEficiencia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane7.setViewportView(tblEficiencia);

        scrollPane7.add(jScrollPane7);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 677, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 174, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(scrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 56, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Eficiencia Proceso", jPanel7);

        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        lblArticuloVar.setText("Articulo:");
        jPanel16.add(lblArticuloVar);

        cbArticuloVar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbArticuloVar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbArticuloVarActionPerformed(evt);
            }
        });
        jPanel16.add(cbArticuloVar);

        lblProveedor.setText("Proveedor:");
        jPanel16.add(lblProveedor);

        cbProveedorVar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel16.add(cbProveedorVar);

        btnBuscarVariacion.setText("Buscar Variacion");
        btnBuscarVariacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarVariacionActionPerformed(evt);
            }
        });
        jPanel16.add(btnBuscarVariacion);

        tblVariacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane8.setViewportView(tblVariacion);

        scrollPane8.add(jScrollPane8);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(223, 223, 223)
                .addComponent(scrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Variacion Precios", jPanel8);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarHistorialActionPerformed
        String articuloSeleccionado = (String) cbArticulo.getSelectedItem();
    if (articuloSeleccionado == null) {
        JOptionPane.showMessageDialog(this, "Seleccione un artículo");
        return;
    }
    
    modeloHistorial.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        // Obtener ID del artículo
        qry = "SELECT ID FROM ARTICULOS WHERE Nombre = ?";
        ps = conn.prepareStatement(qry);
        ps.setString(1, articuloSeleccionado);
        rs = ps.executeQuery();
        
        int articuloID = 0;
        if (rs.next()) {
            articuloID = rs.getInt("ID");
        }
        rs.close();
        ps.close();
        
        // Consulta principal
        qry = "SELECT A.Nombre AS Articulo, A.Codigo, PROV.Empresa AS Proveedor, " +
              "P.Nombre + ' ' + P.Apellido AS Contacto, DA.Precio_Unitario_Acordado, " +
              "DA.Cantidad, DA.Cantidad * DA.Precio_Unitario_Acordado AS Monto_Total, " +
              "ADJ.Fecha_Resolucion, PRES.Unidad_Medida " +
              "FROM DETALLE_ADJUDICACIONES DA " +
              "INNER JOIN ADJUDICACIONES ADJ ON DA.Fk_AdjudicacionesID = ADJ.ID " +
              "INNER JOIN PROVEEDORES PROV ON DA.Fk_ProveedorID = PROV.ID " +
              "INNER JOIN PERSONAS P ON PROV.Fk_Persona_ID = P.ID " +
              "INNER JOIN DETALLE_ORDEN_COMPRA DOC ON DA.Fk_DetalleID = DOC.ID " +
              "INNER JOIN PRESENTACIONES PRES ON DOC.Fk_PresentacionID = PRES.ID " +
              "INNER JOIN ARTICULOS A ON PRES.Fk_ArticuloID = A.ID " +
              "WHERE A.ID = ? " +
              "ORDER BY ADJ.Fecha_Resolucion DESC";
        
        ps = conn.prepareStatement(qry);
        ps.setInt(1, articuloID);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getString("Articulo"),
                rs.getString("Codigo"),
                rs.getString("Proveedor"),
                rs.getString("Contacto"),
                String.format("Q %.2f", rs.getBigDecimal("Precio_Unitario_Acordado")),
                rs.getInt("Cantidad"),
                String.format("Q %.2f", rs.getBigDecimal("Monto_Total")),
                rs.getDate("Fecha_Resolucion"),
                rs.getString("Unidad_Medida")
            };
            modeloHistorial.addRow(fila);
        }
        
        if (modeloHistorial.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No se encontró historial para este artículo");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnBuscarHistorialActionPerformed

    private void btnBuscarRankingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarRankingActionPerformed
        if (dtFechaInicio.getDate() == null || dtFechaFin.getDate() == null) {
        JOptionPane.showMessageDialog(this, "Seleccione ambas fechas");
        return;
    }
    
    modeloRanking.setRowCount(0);
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    try {
        conn = cn.getConnection();
        
        qry = "SELECT TOP 5 PROV.Empresa AS Proveedor, " +
              "P.Nombre + ' ' + P.Apellido AS Contacto, " +
              "PROV.Telefono_Comercial, PROV.Email_Comercial, " +
              "COUNT(DISTINCT DA.Fk_AdjudicacionesID) AS Total_Adjudicaciones, " +
              "SUM(DA.Cantidad * DA.Precio_Unitario_Acordado) AS Monto_Total, " +
              "AVG(DA.Precio_Unitario_Acordado) AS Precio_Promedio " +
              "FROM DETALLE_ADJUDICACIONES DA " +
              "INNER JOIN PROVEEDORES PROV ON DA.Fk_ProveedorID = PROV.ID " +
              "INNER JOIN PERSONAS P ON PROV.Fk_Persona_ID = P.ID " +
              "INNER JOIN ADJUDICACIONES ADJ ON DA.Fk_AdjudicacionesID = ADJ.ID " +
              "WHERE ADJ.Fecha_Resolucion BETWEEN ? AND ? " +
              "GROUP BY PROV.ID, PROV.Empresa, P.Nombre, P.Apellido, " +
              "PROV.Telefono_Comercial, PROV.Email_Comercial " +
              "ORDER BY Monto_Total DESC";
        
        ps = conn.prepareStatement(qry);
        ps.setString(1, sdf.format(dtFechaInicio.getDate()));
        ps.setString(2, sdf.format(dtFechaFin.getDate()));
        rs = ps.executeQuery();
        
        int ranking = 1;
        while (rs.next()) {
            Object[] fila = {
                ranking++,
                rs.getString("Proveedor"),
                rs.getString("Contacto"),
                rs.getString("Telefono_Comercial"),
                rs.getString("Email_Comercial"),
                rs.getInt("Total_Adjudicaciones"),
                String.format("Q %.2f", rs.getBigDecimal("Monto_Total")),
                String.format("Q %.2f", rs.getBigDecimal("Precio_Promedio"))
            };
            modeloRanking.addRow(fila);
        }
        
        if (modeloRanking.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No se encontraron datos en ese rango de fechas");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnBuscarRankingActionPerformed

    private void btnBuscarOfertasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarOfertasActionPerformed
       String ordenSeleccionada = (String) cbOrdenCompra.getSelectedItem();
    if (ordenSeleccionada == null) {
        JOptionPane.showMessageDialog(this, "Seleccione una orden");
        return;
    }
    
    modeloOfertas.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        // Extraer ID de la orden
        int ordenID = Integer.parseInt(ordenSeleccionada.split(" - ")[0]);
        
        qry = "SELECT A.Nombre AS Articulo, PRES.Unidad_Medida, " +
              "DOC.Cantidad AS Cantidad_Solicitada, PROV.Empresa AS Proveedor, " +
              "OP.Precio_Unitario, OP.Precio_Unitario * DOC.Cantidad AS Monto_Total, " +
              "CP.Condiciones, OP.Fecha_De_Entrega, " +
              "CASE WHEN DA.ID IS NOT NULL THEN 'GANADOR' ELSE 'No seleccionado' END AS Estado " +
              "FROM DETALLE_ORDEN_COMPRA DOC " +
              "INNER JOIN PRESENTACIONES PRES ON DOC.Fk_PresentacionID = PRES.ID " +
              "INNER JOIN ARTICULOS A ON PRES.Fk_ArticuloID = A.ID " +
              "LEFT JOIN OFERTA_PROVEEDOR OP ON DOC.ID = OP.Fk_DetalleOrdenID " +
              "LEFT JOIN PROVEEDORES PROV ON OP.Fk_ProveedorID = PROV.ID " +
              "LEFT JOIN CONDICIONES_PAGO CP ON OP.Fk_CondicionesPagoID = CP.ID " +
              "LEFT JOIN DETALLE_ADJUDICACIONES DA ON OP.ID = DA.Fk_OfertaProveedorID " +
              "WHERE DOC.Fk_OrdenID = ? " +
              "ORDER BY A.Nombre, OP.Precio_Unitario ASC";
        
        ps = conn.prepareStatement(qry);
        ps.setInt(1, ordenID);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getString("Articulo"),
                rs.getString("Unidad_Medida"),
                rs.getInt("Cantidad_Solicitada"),
                rs.getString("Proveedor"),
                rs.getBigDecimal("Precio_Unitario") != null ? 
                    String.format("Q %.2f", rs.getBigDecimal("Precio_Unitario")) : "N/A",
                rs.getBigDecimal("Monto_Total") != null ? 
                    String.format("Q %.2f", rs.getBigDecimal("Monto_Total")) : "N/A",
                rs.getString("Condiciones"),
                rs.getDate("Fecha_De_Entrega"),
                rs.getString("Estado")
            };
            modeloOfertas.addRow(fila);
        }
        
        lblResumenOfertas.setText("Total de ofertas: " + modeloOfertas.getRowCount());
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    } 
    }//GEN-LAST:event_btnBuscarOfertasActionPerformed

    private void btnCargarPendientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarPendientesActionPerformed
        modeloPendientes.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        qry = "SELECT PI.ID, P.Nombre + ' ' + P.Apellido AS Solicitante, " +
              "RL.Rol, D.Area, S.Nombre AS Sucursal, PI.Fecha_Pedido, " +
              "PI.Fecha_Estimada_Entrega, E.Estado, " +
              "DATEDIFF(DAY, PI.Fecha_Pedido, GETDATE()) AS Dias_Pendiente " +
              "FROM PEDIDOS_INTERNOS PI " +
              "INNER JOIN PERSONAL PER ON PI.Fk_Personal_ID = PER.ID " +
              "INNER JOIN PERSONAS P ON PER.Fk_Persona_ID = P.ID " +
              "INNER JOIN ROLES_LABORALES RL ON PER.Fk_RolLaboral_ID = RL.ID " +
              "INNER JOIN DEPARTAMENTO D ON PER.Fk_Departamento_ID = D.ID " +
              "LEFT JOIN SUCURSALES S ON D.FK_Sucursal_ID = S.ID " +
              "INNER JOIN ESTADO E ON PI.Fk_Estado_ID = E.ID " +
              "WHERE PI.Fk_OrdenCompra_ID IS NULL " +
              "ORDER BY PI.Fecha_Pedido ASC";
        
        ps = conn.prepareStatement(qry);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getInt("ID"),
                rs.getString("Solicitante"),
                rs.getString("Rol"),
                rs.getString("Area"),
                rs.getString("Sucursal"),
                rs.getTimestamp("Fecha_Pedido"),
                rs.getDate("Fecha_Estimada_Entrega"),
                rs.getString("Estado"),
                rs.getInt("Dias_Pendiente")
            };
            modeloPendientes.addRow(fila);
        }
        
        lblTotalPendientes.setText("Total: " + modeloPendientes.getRowCount());
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnCargarPendientesActionPerformed

    private void btnCargarActivasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarActivasActionPerformed
        modeloActivas.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        qry = "SELECT OC.ID, OC.Fecha_Emision, OC.Fecha_Limite_Ofertas, " +
              "DATEDIFF(DAY, GETDATE(), OC.Fecha_Limite_Ofertas) AS Dias_Restantes, " +
              "P.Nombre + ' ' + P.Apellido AS Responsable, PRIOR.Prioridad, " +
              "E.Estado, COUNT(DISTINCT DOC.ID) AS Total_Items, " +
              "COUNT(DISTINCT OP.Fk_ProveedorID) AS Proveedores " +
              "FROM ORDENES_DE_COMPRA OC " +
              "INNER JOIN PERSONAL PER ON OC.Fk_Personal_ID = PER.ID " +
              "INNER JOIN PERSONAS P ON PER.Fk_Persona_ID = P.ID " +
              "INNER JOIN PRIORIDAD PRIOR ON OC.Fk_Prioridad_ID = PRIOR.ID " +
              "INNER JOIN ESTADO E ON OC.Fk_Estado_ID = E.ID " +
              "LEFT JOIN DETALLE_ORDEN_COMPRA DOC ON OC.ID = DOC.Fk_OrdenID " +
              "LEFT JOIN OFERTA_PROVEEDOR OP ON DOC.ID = OP.Fk_DetalleOrdenID " +
              "WHERE OC.Fecha_Limite_Ofertas >= GETDATE() " +
              "AND OC.Activo = 1 " +
              "AND NOT EXISTS (SELECT 1 FROM ADJUDICACIONES ADJ WHERE ADJ.Fk_OrdenID = OC.ID) " +
              "GROUP BY OC.ID, OC.Fecha_Emision, OC.Fecha_Limite_Ofertas, " +
              "P.Nombre, P.Apellido, PRIOR.Prioridad, E.Estado " +
              "ORDER BY Dias_Restantes ASC";
        
        ps = conn.prepareStatement(qry);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getInt("ID"),
                rs.getTimestamp("Fecha_Emision"),
                rs.getTimestamp("Fecha_Limite_Ofertas"),
                rs.getInt("Dias_Restantes"),
                rs.getString("Responsable"),
                rs.getString("Prioridad"),
                rs.getString("Estado"),
                rs.getInt("Total_Items"),
                rs.getInt("Proveedores")
            };
            modeloActivas.addRow(fila);
        }
        
        lblTotalActivas.setText("Total: " + modeloActivas.getRowCount());
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnCargarActivasActionPerformed

    private void btnBuscarGastosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarGastosActionPerformed
        String sucursalSeleccionada = (String) cbSucursal.getSelectedItem();
    if (sucursalSeleccionada == null) {
        JOptionPane.showMessageDialog(this, "Seleccione una sucursal");
        return;
    }
    
    modeloGastos.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        // Obtener ID de sucursal
        qry = "SELECT ID FROM SUCURSALES WHERE Nombre = ?";
        ps = conn.prepareStatement(qry);
        ps.setString(1, sucursalSeleccionada);
        rs = ps.executeQuery();
        
        int sucursalID = 0;
        if (rs.next()) {
            sucursalID = rs.getInt("ID");
        }
        rs.close();
        ps.close();
        
        int anio = (Integer) spAnio.getValue();
        
        qry = "SELECT D.Area AS Departamento, S.Nombre AS Sucursal, " +
              "COUNT(DISTINCT OC.ID) AS Total_Ordenes, " +
              "COUNT(DISTINCT DA.ID) AS Total_Adjudicaciones, " +
              "SUM(DA.Cantidad * DA.Precio_Unitario_Acordado) AS Monto_Total, " +
              "AVG(DA.Precio_Unitario_Acordado) AS Precio_Promedio, " +
              "MIN(ADJ.Fecha_Resolucion) AS Primera_Compra, " +
              "MAX(ADJ.Fecha_Resolucion) AS Ultima_Compra " +
              "FROM DEPARTAMENTO D " +
              "INNER JOIN SUCURSALES S ON D.FK_Sucursal_ID = S.ID " +
              "INNER JOIN PERSONAL PER ON PER.Fk_Departamento_ID = D.ID " +
              "INNER JOIN ORDENES_DE_COMPRA OC ON OC.Fk_Personal_ID = PER.ID " +
              "INNER JOIN ADJUDICACIONES ADJ ON ADJ.Fk_OrdenID = OC.ID " +
              "INNER JOIN DETALLE_ADJUDICACIONES DA ON DA.Fk_AdjudicacionesID = ADJ.ID " +
              "WHERE D.FK_Sucursal_ID = ? AND YEAR(ADJ.Fecha_Resolucion) = ? " +
              "GROUP BY D.ID, D.Area, S.Nombre " +
              "ORDER BY Monto_Total DESC";
        
        ps = conn.prepareStatement(qry);
        ps.setInt(1, sucursalID);
        ps.setInt(2, anio);
        rs = ps.executeQuery();
        
        BigDecimal totalGeneral = BigDecimal.ZERO;
        
        while (rs.next()) {
            BigDecimal monto = rs.getBigDecimal("Monto_Total");
            if (monto != null) {
                totalGeneral = totalGeneral.add(monto);
            }
            
            Object[] fila = {
                rs.getString("Departamento"),
                rs.getString("Sucursal"),
                rs.getInt("Total_Ordenes"),
                rs.getInt("Total_Adjudicaciones"),
                String.format("Q %.2f", monto),
                String.format("Q %.2f", rs.getBigDecimal("Precio_Promedio")),
                rs.getDate("Primera_Compra"),
                rs.getDate("Ultima_Compra")
            };
            modeloGastos.addRow(fila);
        }
        
        lblTotalGasto.setText(String.format("Total Gastado: Q %.2f", totalGeneral));
        
        if (modeloGastos.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No se encontraron datos para esa sucursal y año");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnBuscarGastosActionPerformed

    private void btnCalcularEficienciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularEficienciaActionPerformed
        modeloEficiencia.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        // Estadísticas generales
        qry = "SELECT COUNT(*) AS Total, " +
              "AVG(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Promedio, " +
              "MIN(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Minimo, " +
              "MAX(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Maximo, " +
              "STDEV(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Desviacion " +
              "FROM ORDENES_DE_COMPRA OC " +
              "INNER JOIN ADJUDICACIONES ADJ ON ADJ.Fk_OrdenID = OC.ID";
        
        ps = conn.prepareStatement(qry);
        rs = ps.executeQuery();
        
        if (rs.next()) {
            lblPromedio.setText(String.format("Días Promedio: %.2f", rs.getDouble("Promedio")));
            lblMinimo.setText(String.format("Días Mínimo: %d", rs.getInt("Minimo")));
            lblMaximo.setText(String.format("Días Máximo: %d", rs.getInt("Maximo")));
            double desviacion = rs.getDouble("Desviacion");
            lblDesviacion.setText(String.format("Desviación Estándar: %.2f", 
                rs.wasNull() ? 0.0 : desviacion));
        }
        rs.close();
        ps.close();
        
        // Por prioridad
        qry = "SELECT PRIOR.Prioridad, COUNT(*) AS Total, " +
              "AVG(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Promedio, " +
              "MIN(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Minimo, " +
              "MAX(DATEDIFF(DAY, OC.Fecha_Emision, ADJ.Fecha_Resolucion)) AS Maximo " +
              "FROM ORDENES_DE_COMPRA OC " +
              "INNER JOIN ADJUDICACIONES ADJ ON ADJ.Fk_OrdenID = OC.ID " +
              "INNER JOIN PRIORIDAD PRIOR ON OC.Fk_Prioridad_ID = PRIOR.ID " +
              "GROUP BY PRIOR.ID, PRIOR.Prioridad " +
              "ORDER BY Promedio";
        
        ps = conn.prepareStatement(qry);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            Object[] fila = {
                rs.getString("Prioridad"),
                rs.getInt("Total"),
                String.format("%.2f", rs.getDouble("Promedio")),
                rs.getInt("Minimo"),
                rs.getInt("Maximo")
            };
            modeloEficiencia.addRow(fila);
        }
        
        if (modeloEficiencia.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No hay datos de adjudicaciones para calcular");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnCalcularEficienciaActionPerformed

    private void cbArticuloVarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbArticuloVarActionPerformed
        cargarProveedoresPorArticulo();
    }//GEN-LAST:event_cbArticuloVarActionPerformed

    private void btnBuscarVariacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarVariacionActionPerformed
        String articuloSel = (String) cbArticuloVar.getSelectedItem();
    String proveedorSel = (String) cbProveedorVar.getSelectedItem();
    
    if (articuloSel == null || proveedorSel == null) {
        JOptionPane.showMessageDialog(this, "Seleccione artículo y proveedor");
        return;
    }
    
    modeloVariacion.setRowCount(0);
    
    try {
        conn = cn.getConnection();
        
        // Obtener ID del artículo
        qry = "SELECT ID FROM ARTICULOS WHERE Nombre = ?";
        ps = conn.prepareStatement(qry);
        ps.setString(1, articuloSel);
        rs = ps.executeQuery();
        int articuloID = 0;
        if (rs.next()) articuloID = rs.getInt("ID");
        rs.close();
        ps.close();
        
        // Obtener ID del proveedor
        int proveedorID = Integer.parseInt(proveedorSel.split(" - ")[0]);
        
        qry = "SELECT A.Nombre AS Articulo, PRES.Unidad_Medida, PROV.Empresa, " +
              "OP.Fecha_Que_Ofertó, OP.Precio_Unitario, CP.Condiciones, " +
              "CASE WHEN DA.ID IS NOT NULL THEN 'ADJUDICADO' ELSE 'No adjudicado' END AS Resultado, " +
              "LAG(OP.Precio_Unitario) OVER (ORDER BY OP.Fecha_Que_Ofertó) AS Precio_Anterior, " +
              "OP.Precio_Unitario - LAG(OP.Precio_Unitario) OVER (ORDER BY OP.Fecha_Que_Ofertó) AS Variacion, " +
              "CASE WHEN LAG(OP.Precio_Unitario) OVER (ORDER BY OP.Fecha_Que_Ofertó) IS NOT NULL " +
              "THEN ((OP.Precio_Unitario - LAG(OP.Precio_Unitario) OVER (ORDER BY OP.Fecha_Que_Ofertó)) / " +
              "LAG(OP.Precio_Unitario) OVER (ORDER BY OP.Fecha_Que_Ofertó)) * 100 " +
              "ELSE NULL END AS Variacion_Porcentual " +
              "FROM OFERTA_PROVEEDOR OP " +
              "INNER JOIN DETALLE_ORDEN_COMPRA DOC ON OP.Fk_DetalleOrdenID = DOC.ID " +
              "INNER JOIN PRESENTACIONES PRES ON DOC.Fk_PresentacionID = PRES.ID " +
              "INNER JOIN ARTICULOS A ON PRES.Fk_ArticuloID = A.ID " +
              "INNER JOIN PROVEEDORES PROV ON OP.Fk_ProveedorID = PROV.ID " +
              "INNER JOIN CONDICIONES_PAGO CP ON OP.Fk_CondicionesPagoID = CP.ID " +
              "LEFT JOIN DETALLE_ADJUDICACIONES DA ON OP.ID = DA.Fk_OfertaProveedorID " +
              "WHERE A.ID = ? AND PROV.ID = ? " +
              "ORDER BY OP.Fecha_Que_Ofertó DESC";
        
        ps = conn.prepareStatement(qry);
        ps.setInt(1, articuloID);
        ps.setInt(2, proveedorID);
        rs = ps.executeQuery();
        
        while (rs.next()) {
            BigDecimal precioAnterior = rs.getBigDecimal("Precio_Anterior");
            BigDecimal variacion = rs.getBigDecimal("Variacion");
            BigDecimal variacionPct = rs.getBigDecimal("Variacion_Porcentual");
            
            Object[] fila = {
                rs.getString("Articulo"),
                rs.getString("Unidad_Medida"),
                rs.getString("Empresa"),
                rs.getTimestamp("Fecha_Que_Ofertó"),
                String.format("Q %.2f", rs.getBigDecimal("Precio_Unitario")),
                precioAnterior != null ? String.format("Q %.2f", precioAnterior) : "N/A",
                variacion != null ? String.format("Q %.2f", variacion) : "N/A",
                variacionPct != null ? String.format("%.2f%%", variacionPct) : "N/A",
                rs.getString("Resultado"),
                rs.getString("Condiciones")
            };
            modeloVariacion.addRow(fila);
        }
        
        if (modeloVariacion.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No se encontró historial de ofertas");
        }
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    } finally {
        cerrarConexiones();
    }
    }//GEN-LAST:event_btnBuscarVariacionActionPerformed

    // Variables de conexión
private conexionSQLServer cn = new conexionSQLServer();
private Connection conn;
private PreparedStatement ps;
private ResultSet rs;
private String qry;

// Modelos de tablas
private DefaultTableModel modeloHistorial;
private DefaultTableModel modeloRanking;
private DefaultTableModel modeloOfertas;
private DefaultTableModel modeloPendientes;
private DefaultTableModel modeloActivas;
private DefaultTableModel modeloGastos;
private DefaultTableModel modeloEficiencia;
private DefaultTableModel modeloVariacion;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarGastos;
    private javax.swing.JButton btnBuscarHistorial;
    private javax.swing.JButton btnBuscarOfertas;
    private javax.swing.JButton btnBuscarRanking;
    private javax.swing.JButton btnBuscarVariacion;
    private javax.swing.JButton btnCalcularEficiencia;
    private javax.swing.JButton btnCargarActivas;
    private javax.swing.JButton btnCargarPendientes;
    private javax.swing.JButton btnExportarHistorial;
    private javax.swing.JComboBox<String> cbArticulo;
    private javax.swing.JComboBox<String> cbArticuloVar;
    private javax.swing.JComboBox<String> cbOrdenCompra;
    private javax.swing.JComboBox<String> cbProveedorVar;
    private javax.swing.JComboBox<String> cbSucursal;
    private com.toedter.calendar.JDateChooser dtFechaFin;
    private com.toedter.calendar.JDateChooser dtFechaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblAnio;
    private javax.swing.JLabel lblArticuloVar;
    private javax.swing.JLabel lblDesviacion;
    private javax.swing.JLabel lblMaximo;
    private javax.swing.JLabel lblMinimo;
    private javax.swing.JLabel lblPromedio;
    private javax.swing.JLabel lblProveedor;
    private javax.swing.JLabel lblResumenOfertas;
    private javax.swing.JLabel lblTotalActivas;
    private javax.swing.JLabel lblTotalGasto;
    private javax.swing.JLabel lblTotalPendientes;
    private java.awt.ScrollPane scrollPane1;
    private java.awt.ScrollPane scrollPane2;
    private java.awt.ScrollPane scrollPane3;
    private java.awt.ScrollPane scrollPane4;
    private java.awt.ScrollPane scrollPane5;
    private java.awt.ScrollPane scrollPane6;
    private java.awt.ScrollPane scrollPane7;
    private java.awt.ScrollPane scrollPane8;
    private javax.swing.JSpinner spAnio;
    private javax.swing.JTable tblActivas;
    private javax.swing.JTable tblEficiencia;
    private javax.swing.JTable tblGastos;
    private javax.swing.JTable tblHistorial;
    private javax.swing.JTable tblOfertas;
    private javax.swing.JTable tblPendientes;
    private javax.swing.JTable tblRanking;
    private javax.swing.JTable tblVariacion;
    // End of variables declaration//GEN-END:variables
}
